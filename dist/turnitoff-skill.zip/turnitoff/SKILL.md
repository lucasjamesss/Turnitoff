---
name: turnitoff
description: Use when writing prose the user will send or submit as themselves (emails, essays, reports, posts) so it reads like one person, not a template. Not for code or short chat replies.
---

# Turnitoff

Apply this to prose the user will send or submit as themselves: emails, essays, reports, posts. Skip it for code and for short chat replies.

Write like one specific person, not a template.

1. Answer or claim first. No intro, no recap, no "In conclusion".
2. Real specifics only: names, numbers, places, one example. If none were given, ask or leave [gap]. Never invent.
3. Vary rhythm hard. Mix 3-word and 30-word sentences. Never three similar-length sentences in a row. Uneven paragraphs. Fragments and contractions are fine.
4. Banned words: delve, tapestry, landscape, pivotal, crucial, underscore, showcase, foster, enhance, testament, intricate, multifaceted, holistic, robust, seamless, leverage, utilize, navigate, realm, journey, vibrant, "in today's", "it's worth noting", "when it comes to", Moreover, Furthermore, Additionally.
5. Banned shapes: "not just X, but Y" and "it's not X, it's Y" (say Y); rule-of-three lists by reflex; trailing ", highlighting/ensuring/underscoring..." clauses; closing summaries.
6. No em dashes. Commas or periods.
7. No bold-lead bullets, emoji, or headers on short pieces.
8. One hedge per claim. Say "I don't know" when true.
9. Fix a flagged sentence by rewriting it. Never swap in a synonym.
10. Review repeated openings and phrases even if the score is clean. Rewrite from meaning; keep facts and technical terms. Repetition flags are not word probabilities.

## Check the draft

If you can run code, save the draft to a file and scan it before you send it. Run this from the skill folder:

    python3 scripts/scan.py draft.txt

- `clean`: send it.
- `minor-tells`: fix what is cheap to fix.
- `reads-AI`: rewrite the flagged sentences from the underlying facts, then scan again. After three passes, send it and tell the user it still flags.

Review repeated-opening and repeated-phrase findings even when the verdict is clean. Rewrite from the meaning and rescan, up to three passes. Preserve facts and technical terms; keep deliberate repetition when it helps clarity. Never add errors or unusual synonyms to lower a score. These flags measure repetition patterns, not next-word probabilities. The scanner reports; the writing assistant edits.

If you can't run code, apply the rule by hand. The full version is in `references/RULES.md`.

Don't mention the scan to the user unless they ask.

## Limits

No tool guarantees a pass in any detector. Formal prose and non-native English get flagged even when a human wrote every word. The user should follow their school or workplace rules on AI use.
