"""Scan a draft for AI-writing tells.

Usage: python3 scan.py FILE [--formal]     (use - for stdin)
Exit 0 if the draft is fine, 1 if it reads as AI.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scanner import analyze, report  # noqa: E402


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 2
    if args[0] == "-":
        text = sys.stdin.read()
    else:
        with open(args[0], encoding="utf-8") as f:
            text = f.read()
    score, findings, words = analyze(text, "--formal" in sys.argv)
    print(report(score, findings, words))
    if words < 80:
        print("  (under 80 words: stats unreliable)")
    return 0 if score < 6 else 1


sys.exit(main())
